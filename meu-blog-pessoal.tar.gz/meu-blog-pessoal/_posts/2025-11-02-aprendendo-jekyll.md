--
layout: post
title: "Bem-vindo ao meu blog!"
date: 2025-11-02 00:00:00 -0300
categories: geral
---

Este é o meu post sobre aprendendo-jekyll.

## Por que criar este post?

- Documentar meu progresso
- Compartilhar conhecimento
- Praticar jekyll
- Construir portfólio