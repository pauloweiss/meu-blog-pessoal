---
layout: page
title: Sobre
permalink: /about/
---

Olá! Sou um desenvolvedor web iniciante compartilhando minha jornada de aprendizado.

## Tecnologias que estou estudando:

- HTML, CSS, JavaScript
- Jekyll e sites estáticos
- Git e GitHub
- Linux (Debian)